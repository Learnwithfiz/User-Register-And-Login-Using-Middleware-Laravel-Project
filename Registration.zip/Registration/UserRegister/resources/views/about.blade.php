@if (session('email'))
{{session('email')}}  
@endif

<h1>Admin Dashboard About Page</h1>
<a href="{{url('/logout')}}">Logout</a>