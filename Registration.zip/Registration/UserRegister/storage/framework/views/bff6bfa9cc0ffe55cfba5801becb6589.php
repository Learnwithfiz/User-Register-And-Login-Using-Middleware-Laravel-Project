<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Registration</title>
</head>
<body>
    <form action="<?php echo e(url('/insert')); ?>" method="post">
        <?php echo csrf_field(); ?>
        <input type="text" name="name" placeholder="enter name"> <br>
        <input type="email"name="email" placeholder="enter email" > <br>
        <input type="password"name="pass" placeholder="enter password"> <br>
        <button>Register </button><br>
        <a href="<?php echo e(url('/login')); ?>">Login</a>
    </form>
</body>
</html><?php /**PATH C:\Users\User\Desktop\Batch 02 Laravel\Registration\UserRegister\resources\views/index.blade.php ENDPATH**/ ?>