<?php if(session('email')): ?>
<?php echo e(session('email')); ?>  
<?php endif; ?>

<h1>Admin Dashboard</h1>
<a href="<?php echo e(url('/logout')); ?>">Logout</a><?php /**PATH C:\Users\User\Desktop\Batch 02 Laravel\Registration\UserRegister\resources\views/admin.blade.php ENDPATH**/ ?>