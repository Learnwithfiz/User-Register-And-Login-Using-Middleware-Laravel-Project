<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\dashboard;
class UserController extends Controller
{
    public function OnShow(){
        return view('index');
    }
    public function OnInsert(Request $req){
       $info = new dashboard();
       $info->name = $req->name ;
       $info->email = $req->email ;
       $info->pass = $req->pass ;
       $info->save();
       return redirect('/');
    }

    public function Login(){
        return view('login');
    }

    public function CheckedLogin(Request $req){
        $email = $req->email ;
        $pass = $req->pass ;

       $count = dashboard::where('email','=',$email)
       ->where('pass','=',$pass)->count();
      
       if($count==1){
          $req->session()->put('email',$email);
          return redirect('/admin');
       }else{
        return "Login failed ";
       }
    }

    public function OnAdmin(){
        return view('admin');
    }

    public function OnLogout(Request $req){
      $req->session()->flush();

      return view('login');
    }

    public function OnAbout(){
        return view('about');
    }
}
